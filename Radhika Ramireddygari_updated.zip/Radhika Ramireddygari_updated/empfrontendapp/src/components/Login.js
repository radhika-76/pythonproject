function Login(){
    return(
        <p>Login component</p>
    );
}
export default Login;