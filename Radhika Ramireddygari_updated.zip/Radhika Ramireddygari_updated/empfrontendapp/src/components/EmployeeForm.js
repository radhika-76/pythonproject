import React,{useState} from 'react';
import {addEmployee} from '../service/sendDetailsToServer';


function EmployeeForm(){
    const [empData,setEmpData] =useState({
        id:"",
        ename:""
    });




const {id,ename}=empData;//destructuring

const changeHandler = e=>{
        setEmpData(
            {
                ...empData,[e.target.name]: [e.target.value]
            }
        );
    }
    const submitHandler = e=>{
        e.preventDefault();
        console.log("Before Add Employee call")
        addEmployee(empData);
        console.log(empData);
    }

    
  return(
    <div class="container-fluid">
	    <div class="row">
		<div class="col-md-12">
        
					<form role="form" onSubmit={submitHandler}>
						<div class="form-group">
							 
							
                            <div class="col-sm-5">
							<label for="exampleInputEName">
								Employee Name
							</label><input type="text" class="form-control form-control-sm" id="exampleInputEName"  placeholder="Enter Employee Name" name="ename" value={ename} onChange={changeHandler}/>
						</div>
                        </div>
						 
						<button type="submit" class="btn btn-primary">
							Add Employee
						</button>
					</form>
				</div>
			</div>   
        
    </div>

    );
    }
export default EmployeeForm;