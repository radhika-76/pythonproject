import {useState,useEffect} from 'react';
//import {employees} from '../service/sendDetailsToServer';
import axios from 'axios';
import {Link} from 'react-router-dom';
function EmployeeList(){
     const [empList,setEmpList] = useState([]);
     //const [employee, setEmployee] = useState([]);
     //const [isLoading, setIsLoading] = useState(false);
     //const [error, setError] = useState(null);
     useEffect(() => {
        axios.get("http://localhost:5000/employees")
              .then(function (response) {
                      setEmpList(response.data)
                   })
              .catch(error => {
                      console.log(error);                        
              })
       }, []);

    return(
        <>
        <p><strong>EmployeeList Component</strong></p>
        <div className="mt-5">
        
        <table class="table table-dark table-striped-columns">
          <thead>
            <tr class="table-primary">
              <th class="table-danger">S.No.</th>
              <th class="table-danger">ID</th>
              <th class="table-danger">Name</th>
              <th class="table-danger">Actions</th>
              
            </tr>
          </thead>
          <tbody>
            {empList.map((item, i) => {
              return (
                <tr key={i + 1} class="table-primary">
                  <td class="table-success">{i + 1}</td>
                  <td class="table-success">{item.id}</td>
                  <td class="table-success">{item.ename}</td>
                  <td class="table-success">
                    <td>
                    <Link className="nav-link" to="/employeedetails" state={{from: `${item.id}`}}>
                      
                      <button type="button" class="btn btn-success">View</button>
                    </Link>
                    </td>
                    <td class="table-success">
                    <Link className="nav-link" to="/editemployeedetails" state={{from: `${item.id}`}}>
                    <button type="button" class="btn btn-primary">Edit</button>
                    </Link>
                    </td>
                    <td class="table-success">
                    <Link className="nav-link" to="/deleteEmployee" state={{from: `${item.id}`}}>
                    <button type="button" class="btn btn-danger">Delete</button>
                    </Link>
                    </td>
                  </td>

                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
        </>
    );

}

export default EmployeeList;