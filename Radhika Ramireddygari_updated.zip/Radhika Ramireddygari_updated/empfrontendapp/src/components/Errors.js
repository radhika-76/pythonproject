function Errors(){
    return(
        <p>Errors component</p>
    );
}
export default Errors;