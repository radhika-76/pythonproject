function AboutUs(){
    return(
        <p>About Us</p>
    );

}
export default AboutUs;