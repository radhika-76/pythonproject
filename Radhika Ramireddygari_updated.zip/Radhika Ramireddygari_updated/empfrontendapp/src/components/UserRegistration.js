function UserRegistration(){
   return(
        <p>UserRegistration component</p>
    );
}
export default UserRegistration;