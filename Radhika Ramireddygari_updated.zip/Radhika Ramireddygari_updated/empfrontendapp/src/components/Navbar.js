import {Link} from 'react-router-dom';
function Navbar(){
    return(

    <div class="container-fluid">
	<div class="row">
		<div class="col-md-12">
        <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-dark bg-dark">
				 
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="navbar-nav">
                <li class="nav-item active">
                     
            <Link className="nav-link" to="/addEmployee">Creat new Employee</Link>
            
         
                </li>
                
                <li class="nav-item">
                     
                     <Link className="nav-link" to="/employees">List of Employees</Link>
                </li>
                </ul>
            
            
        </div>
    </nav>
        
            
         </div>
         </div>
         </div>
        
    );
}

export default Navbar;