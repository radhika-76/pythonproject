import {useState,useEffect} from 'react';
import axios from 'axios';
import {useLocation} from "react-router-dom";
function EmployeeDetails(){
    const [employee,setEmployee] = useState([]);
    const location = useLocation();
    const {from} =location.state;

    const id =1
     
     useEffect(() => {
        axios.get(`http://localhost:5000/employees/${from}`)
              .then(function (response) {
                setEmployee(response.data)
                   })
              .catch(error => {
                      console.log(error);                        
              })
       }, []);

    return(
        <>
        <div class="container-fluid">
	    <div class="row">
		<div class="col-md-12">
        <p><strong>Employee Details </strong></p>
        <dl class="row">
         <dt class="col-sm-3">Employee Id</dt>
         <dd class="col-sm-9">{employee.id}</dd>
         </dl>
         <dl class="row">
         <dt class="col-sm-3">Employee Name</dt>
         <dd class="col-sm-9">{employee.ename}</dd>
         </dl>
       </div> 
       </div>
       </div>
       </>
    );
}

export default EmployeeDetails;