import { BrowserRouter,Routes,Route } from 'react-router-dom';
import  Navbar from './components/Navbar';
import  Home from './components/Home';
import Errors from './components/Errors';
import Login from './components/Login';
import AboutUs from './components/AboutUs';
import EmployeeList from './components/EmployeeList';
import EmployeeForm  from './components/EmployeeForm';
import EmployeeDetails  from './components/EmployeeDetails';
import UserRegistration  from './components/UserRegistration';
import EditEmployeeDetails from "./components/EditEmployeeDetails";

import DeleteEmployee  from './components/DeleteEmployee';

function App(){
    return (
        <BrowserRouter>
            <Routes>
            <Route path="/" element={<Navbar />} />
                        <Route path="/home" element={<Home />} />
                        <Route path="/about" element={<AboutUs />}  />
                        <Route path="/login" element={<Login />}  />
                        <Route path="/register" element={<UserRegistration />}  />
                        <Route element={<Errors />} />
                        <Route path="/addEmployee" element={<EmployeeForm />}  />
                        <Route path="/employeedetails" element={<EmployeeDetails />}  />
                        <Route path="/editemployeedetails" element={<EditEmployeeDetails />}  />
                        <Route path="/employees" element={<EmployeeList />}  />
                        <Route path="/deleteEmployee" element={<DeleteEmployee />}  />


            </Routes>
        </BrowserRouter>        
    );
}
export default App;