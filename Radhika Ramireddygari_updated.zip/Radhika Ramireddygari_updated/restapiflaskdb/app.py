# app = Flask(__name__)
# api = Api(app)

# api.add_resource(EmployeeListResource,'/employees')
# api.add_resource(EmployeeResource,'/employees/<int:emp_id>')


from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api
from flask_cors import CORS
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:Bluey%4076@localhost:3306/flasktestdb2'
cors=CORS(app,origins=["*"])
db = SQLAlchemy(app)
api = Api(app)
if __name__ == '__main__':
    app.run(debug=True)

from resources import EmployeeListResource, EmployeeResource

api.add_resource(EmployeeListResource, '/employees')
api.add_resource(EmployeeResource, '/employees/<int:emp_id>')